

# Wedding Website

---

### Overview

This website was built to gather the information about my wedding and keep our friends and family up to date.

The code generates a static web page allowing visitors to browse the sections.


### Features

- The navbar links bring you to the right section and to the social media site
- A map of the location


### Resources

Resource used in the project project:

	 - MDB Bootstrap
	 - Cloudinary
	 - Google Maps API



